package com.leroy.spclient.gui;

import com.leroy.spclient.features.FeatureManager;
import com.leroy.spclient.features.Waypoint;
import com.leroy.spclient.features.WaypointManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class GuiScreenClientOptions extends Screen {
    private final Screen parent;
    private final List<ButtonWidget> buttons = new ArrayList<>();
    private MinecraftClient client;

    public GuiScreenClientOptions(Screen parent) {
        super(Text.literal("SPClient Options"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.client = MinecraftClient.getInstance();
        buttons.clear();
        int y = 40;

        addFeatureToggle("FPS_DISPLAY", "FPS Display", y);
        y += 25;

        addFeatureToggle("ARMOR_HUD", "Armor HUD", y);
        y += 25;

        addFeatureToggle("POTION_HUD", "Potion HUD", y);
        y += 25;

        addFeatureToggle("PLAYER_HEALTH", "Player Health Indicator", y);
        y += 25;

        addFeatureToggle("OWN_NAMETAG", "Show Own Nametag", y);
        y += 25;

        addFeatureToggle("ITEM_PHYSICS", "Item Physics", y);
        y += 25;

        addFeatureToggle("FULL_BRIGHT", "Full Bright", y);
        y += 25;

        addFeatureToggle("ZOOM", "Zoom", y);
        y += 25;

        addFeatureToggle("BLOCK_OUTLINE", "Block Outline", y);
        y += 25;

        addFeatureToggle("PARTICLES", "Particle Filter", y);
        y += 25;

        addFeatureToggle("WAYPOINTS", "Waypoints", y);
        y += 25;

        // Particle Settings Button
        ButtonWidget particleSettingsButton = ButtonWidget.builder(
                Text.literal("Particle Settings"),
                btn -> this.client.setScreen(new GuiScreenParticleSettings(this))
        ).dimensions(this.width / 2 - 100, y, 200, 20).build();

        this.addDrawableChild(particleSettingsButton);
        buttons.add(particleSettingsButton);
        y += 25;

        // Add Waypoint Button
        ButtonWidget waypointAddBtn = ButtonWidget.builder(
                Text.literal("Add Waypoint"),
                btn -> {
                    if (client.player != null && client.world != null) {
                        String dim = client.world.getRegistryKey().getValue().toString();
                        WaypointManager.addWaypoint(new Waypoint("WP_" + WaypointManager.waypoints.size(),
                                client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ(), dim));
                    }
                }
        ).dimensions(this.width / 2 - 100, y, 200, 20).build();

        this.addDrawableChild(waypointAddBtn);
        buttons.add(waypointAddBtn);
        y += 25;

        // Back Button
        ButtonWidget backButton = ButtonWidget.builder(
                Text.literal("Back"),
                btn -> this.client.setScreen(parent)
        ).dimensions(this.width / 2 - 100, this.height - 30, 200, 20).build();

        this.addDrawableChild(backButton);
        buttons.add(backButton);
    }

    private void addFeatureToggle(String featureKey, String displayName, int y) {
        boolean enabled = FeatureManager.isEnabled(featureKey);
        String text = displayName + ": " + (enabled ? "ON" : "OFF");

        ButtonWidget btn = ButtonWidget.builder(
                Text.literal(text),
                b -> {
                    boolean current = FeatureManager.toggleFeature(featureKey);
                    b.setMessage(Text.literal(displayName + ": " + (current ? "ON" : "OFF")));
                }
        ).dimensions(this.width / 2 - 100, y, 200, 20).build();

        this.addDrawableChild(btn);
        buttons.add(btn);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, "SPClient Options", this.width / 2, 15, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}