package com.leroy.spclient;

import com.leroy.spclient.gui.GuiScreenClientOptions;
import com.leroy.spclient.gui.GuiScreenMain;
import com.leroy.spclient.handler.KeybindHandler;
import com.leroy.spclient.features.FeatureManager;
import com.leroy.spclient.features.ZoomHandler;
import com.leroy.spclient.features.WaypointManager;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class MainMod implements ClientModInitializer {

    public static final MinecraftClient mc = MinecraftClient.getInstance();
    public static Screen MAIN_GUI = new GuiScreenMain();
    public static Screen CLIENT_OPTIONS_GUI = new GuiScreenClientOptions();

    @Override
    public void onInitializeClient() {
        // Initialize keybinds
        KeybindHandler.register();

        // Load saved waypoints
        WaypointManager.loadWaypoints();

        // Client tick event
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            KeybindHandler.tick();

            // Zoom tick
            ZoomHandler.tick();

            // Add more ticks here if needed
        });

        // HUD rendering (FPS, Armor HUD, Potion HUD)
        HudRenderCallback.EVENT.register((matrixStack, tickDelta) -> {
            if (mc.currentScreen == null && FeatureManager.isHudEnabled()) {
                GuiScreenMain.renderOverlay(matrixStack);
            }
        });

        // World render (for Waypoints, Block Outline, etc.)
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            FeatureManager.renderWorld(context);
        });
    }
}