package com.leroy.spclient.features;

import net.fabricmc.fabric.api.client.rendering.v1.ParticleRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashSet;
import java.util.Set;

public class ParticleToggleManager {
    private static final Set<String> blockedParticles = new HashSet<>();

    public static void register() {
        ParticleRenderEvents.ALLOW.register((particle, world, x, y, z, velocityX, velocityY, velocityZ) -> {
            Identifier id = Registries.PARTICLE_TYPE.getId(particle);
            if (id != null && blockedParticles.contains(id.getPath())) {
                return false;
            }
            return true;
        });
    }

    public static void block(String particleId) {
        blockedParticles.add(particleId);
        FeatureManager.saveConfig();
    }

    public static void unblock(String particleId) {
        blockedParticles.remove(particleId);
        FeatureManager.saveConfig();
    }

    public static boolean isBlocked(String particleId) {
        return blockedParticles.contains(particleId);
    }

    public static Set<String> getBlockedParticles() {
        return blockedParticles;
    }

    public static void loadFromConfig(Set<String> loaded) {
        blockedParticles.clear();
        blockedParticles.addAll(loaded);
    }

    public static Set<String> getSaveData() {
        return new HashSet<>(blockedParticles);
    }
}