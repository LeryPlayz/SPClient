package com.leroy.spclient.features;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class WaypointManager {
    private static final File FILE = new File("config/spclient_waypoints.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final List<Waypoint> waypoints = new ArrayList<>();

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!FeatureManager.isEnabled("WAYPOINTS")) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            String currentDim = mc.world.getRegistryKey().getValue().toString();
            MatrixStack matrixStack = ctx.matrixStack();
            VertexConsumerProvider.Immediate buffer = mc.getBufferBuilders().getEntityVertexConsumers();
            Vec3d cameraPos = ctx.camera().getPos();

            for (Waypoint wp : waypoints) {
                if (!wp.dimension.equals(currentDim)) continue;

                double dx = wp.x + 0.5 - cameraPos.x;
                double dy = wp.y + 1.5 - cameraPos.y;
                double dz = wp.z + 0.5 - cameraPos.z;

                matrixStack.push();
                matrixStack.translate(dx, dy, dz);
                matrixStack.scale(0.02f, 0.02f, 0.02f);

                Text text = Text.literal(wp.name + " (" + wp.x + " " + wp.y + " " + wp.z + ")");
                int w = mc.textRenderer.getWidth(text) / 2;
                matrixStack.translate(0, 0, 0);
                mc.textRenderer.draw(matrixStack, text, -w, 0, 0xFFFFFF);

                matrixStack.pop();
            }

            buffer.draw();
        });
    }

    public static void addWaypoint(Waypoint wp) {
        waypoints.add(wp);
        save();
    }

    public static void removeWaypoint(String name) {
        waypoints.removeIf(wp -> wp.name.equalsIgnoreCase(name));
        save();
    }

    public static void save() {
        try {
            FILE.getParentFile().mkdirs();
            FileWriter writer = new FileWriter(FILE);
            GSON.toJson(waypoints, writer);
            writer.close();
        } catch (Exception e) {
            System.out.println("Failed to save waypoints: " + e.getMessage());
        }
    }

    public static void load() {
        try {
            if (FILE.exists()) {
                FileReader reader = new FileReader(FILE);
                Type type = new TypeToken<List<Waypoint>>(){}.getType();
                List<Waypoint> loaded = GSON.fromJson(reader, type);
                reader.close();
                if (loaded != null) waypoints.addAll(loaded);
            }
        } catch (Exception e) {
            System.out.println("Failed to load waypoints: " + e.getMessage());
        }
    }
}