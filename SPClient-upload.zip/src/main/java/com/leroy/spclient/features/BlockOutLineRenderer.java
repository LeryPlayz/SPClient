package com.leroy.spclient.features;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

public class BlockOutlineRenderer {

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register((context) -> {
            if (!FeatureManager.isEnabled("BLOCK_OUTLINE")) return;

            MinecraftClient client = MinecraftClient.getInstance();
            if (client.crosshairTarget == null || client.crosshairTarget.getType() != HitResult.Type.BLOCK) return;

            BlockHitResult blockHit = (BlockHitResult) client.crosshairTarget;
            BlockPos pos = blockHit.getBlockPos();

            BlockRenderManager renderManager = client.getBlockRenderManager();
            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider.Immediate buffer = client.getBufferBuilders().getEntityVertexConsumers();

            Camera camera = context.camera();
            matrices.push();
            matrices.translate(-camera.getPos().x, -camera.getPos().y, -camera.getPos().z);

            renderManager.renderBlockOutline(
                matrices,
                buffer.getBuffer(RenderLayer.getLines()),
                client.world.getBlockState(pos),
                pos,
                0.0F, 0.0F, 0.0F,
                client.world,
                0
            );

            matrices.pop();
        });
    }
}