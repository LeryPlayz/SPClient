public static void loadConfig() {
    try {
        if (CONFIG_FILE.exists()) {
            FileReader reader = new FileReader(CONFIG_FILE);
            Type type = new TypeToken<Map<String, Object>>(){}.getType();
            Map<String, Object> raw = GSON.fromJson(reader, type);
            reader.close();

            if (raw != null) {
                for (String key : featureStates.keySet()) {
                    if (raw.containsKey(key)) {
                        featureStates.put(key, (Boolean) raw.get(key));
                    }
                }
                if (raw.containsKey("BLOCKED_PARTICLES")) {
                    Object list = raw.get("BLOCKED_PARTICLES");
                    if (list instanceof java.util.List) {
                        Set<String> blocked = new HashSet<>((java.util.List<String>) list);
                        ParticleToggleManager.loadFromConfig(blocked);
                    }
                }
            }
        }
    } catch (Exception e) {
        System.out.println("Failed to load SPClient config: " + e.getMessage());
    }
}

public static void saveConfig() {
    try {
        CONFIG_FILE.getParentFile().mkdirs();
        Map<String, Object> saveMap = new HashMap<>(featureStates);
        saveMap.put("BLOCKED_PARTICLES", ParticleToggleManager.getSaveData());

        FileWriter writer = new FileWriter(CONFIG_FILE);
        GSON.toJson(saveMap, writer);
        writer.close();
    } catch (Exception e) {
        System.out.println("Failed to save SPClient config: " + e.getMessage());
    }
}