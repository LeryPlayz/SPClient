package com.leroy.spclient.features;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ZoomHandler {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final double ZOOM_AMOUNT = 0.25;
    private static float originalFov = 0;
    private static boolean isZooming = false;

    public static void tick() {
        if (!FeatureManager.isZoomEnabled()) return;

        if (isZoomKeyPressed()) {
            if (!isZooming) {
                startZoom();
            }
        } else {
            if (isZooming) {
                stopZoom();
            }
        }
    }

    private static boolean isZoomKeyPressed() {
        long window = mc.getWindow().getHandle();
        return InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_C);
    }

    private static void startZoom() {
        if (mc.options == null) return;
        originalFov = mc.options.getFov().getValue();
        mc.options.getFov().setValue((float)(originalFov * ZOOM_AMOUNT));
        isZooming = true;
    }

    private static void stopZoom() {
        if (mc.options == null) return;
        mc.options.getFov().setValue(originalFov);
        isZooming = false;
    }
}