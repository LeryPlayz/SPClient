package com.leroy.spclient;

import com.leroy.spclient.gui.GuiScreenClientOptions;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeybindHandler {
    public static final KeyBinding openGuiKey = new KeyBinding(
        "key.spclient.opengui",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_RIGHT_SHIFT,
        "category.spclient"
    );

    public static void handleKeyPresses() {
        if (openGuiKey.wasPressed()) {
            MinecraftClient.getInstance().setScreen(new GuiScreenClientOptions());
        }
    }
}