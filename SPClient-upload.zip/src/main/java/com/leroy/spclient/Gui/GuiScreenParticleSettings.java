package com.leroy.spclient.gui;

import com.leroy.spclient.features.ParticleToggleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.registry.Registries;
import net.minecraft.particle.ParticleType;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class GuiScreenParticleSettings extends Screen {
    private final Screen parent;

    public GuiScreenParticleSettings(Screen parent) {
        super(Text.literal("Particle Toggles"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        List<ParticleType<?>> types = Registries.PARTICLE_TYPE.stream().toList();
        int y = 30;
        for (ParticleType<?> type : types) {
            Identifier id = Registries.PARTICLE_TYPE.getId(type);
            if (id == null) continue;

            String name = id.getPath();
            boolean blocked = ParticleToggleManager.isBlocked(name);
            String label = name + ": " + (blocked ? "OFF" : "ON");

            ButtonWidget btn = ButtonWidget.builder(
                Text.literal(label),
                b -> {
                    if (ParticleToggleManager.isBlocked(name)) {
                        ParticleToggleManager.unblock(name);
                    } else {
                        ParticleToggleManager.block(name);
                    }
                    b.setMessage(Text.literal(name + ": " + (ParticleToggleManager.isBlocked(name) ? "OFF" : "ON")));
                }
            ).dimensions(this.width / 2 - 100, y, 200, 20).build();

            this.addDrawableChild(btn);
            y += 22;
            if (y > this.height - 40) break; // Limit buttons shown
        }

        // Back button
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Back"),
            btn -> this.client.setScreen(parent)
        ).dimensions(this.width / 2 - 100, this.height - 30, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, "Particle Toggles", this.width / 2, 10, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}