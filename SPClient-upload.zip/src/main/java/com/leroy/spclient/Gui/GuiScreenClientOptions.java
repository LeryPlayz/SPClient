// Inside init()
...
addFeatureToggle("WAYPOINTS", "Waypoints", y);
y += 25;

ButtonWidget particleSettingsButton = ButtonWidget.builder(
    Text.literal("Particle Settings"),
    btn -> this.client.setScreen(new GuiScreenParticleSettings(this))
).dimensions(this.width / 2 - 100, y, 200, 20).build();

this.addDrawableChild(particleSettingsButton);
buttons.add(particleSettingsButton);