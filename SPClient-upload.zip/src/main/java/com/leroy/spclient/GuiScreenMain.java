package com.spclient.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

public class GuiScreenMain extends Screen {
    protected GuiScreenMain() {
        super(Text.of("SPClient Menu"));
    }

    @Override
    protected void init() {
        this.addDrawableChild(
            ButtonWidget.builder(Text.of("Client Options"), btn -> {
                MinecraftClient.getInstance().setScreen(new GuiScreenClientOptions());
            }).position(this.width / 2 - 100, this.height / 2 - 30).size(200, 20).build()
        );

        this.addDrawableChild(
            ButtonWidget.builder(Text.of("Close"), btn -> {
                MinecraftClient.getInstance().setScreen(null);
            }).position(this.width / 2 - 100, this.height / 2).size(200, 20).build()
        );
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}