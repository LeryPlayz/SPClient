package com.spclient;

public class FeatureManager {

    public static boolean showFps = true;
    public static boolean showArmorHud = true;
    public static boolean showPotionHud = true;
    public static boolean showPlayerHealth = true;
    public static boolean showOwnNametag = true;
    public static boolean enableItemPhysics = true;
    public static boolean enableFullBright = false;
    public static boolean enableZoom = true;
    public static boolean showBlockOutline = true;
    public static boolean toggleParticles = true;
    public static boolean enableWaypoints = true;

    // You can add methods to toggle features if needed
}